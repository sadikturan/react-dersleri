// class component => state (Component), lifecycle
// function component + state (hooks) 

function App() {
  return (
    <div className="App">
      
    </div>
  );
}

export default App;
