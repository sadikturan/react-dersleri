import { NavLink, Outlet } from "react-router-dom";

export const MainLayout = () => {
    return (
        <div className="main-layout">
            <header>
                <h1>React Router</h1>
                <nav>
                    <NavLink to="/client">Home</NavLink>
                    <NavLink to="about">About</NavLink>
                </nav>
            </header>
            <main>
                <Outlet/>
            </main>
        </div>
    );
}