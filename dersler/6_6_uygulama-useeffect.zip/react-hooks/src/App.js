import NoteList from "./components/NoteList";

function App(props) {
  return (
    <NoteList />
  );
}

export default App;