export const Faq = () => {
    return (
        <div className="faq">
            <h3>Sık Sorulan Sorular</h3>
            <p className="question">
                1- Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores at facere quaerat laborum similique laudantium laboriosam veritatis eos assumenda inventore, repellendus pariatur ad recusandae, provident commodi totam quia vero est?
            </p>
            <p className="question">
                2- Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores at facere quaerat laborum similique laudantium laboriosam veritatis eos assumenda inventore, repellendus pariatur ad recusandae, provident commodi totam quia vero est?
            </p>
            <p className="question">
                3- Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores at facere quaerat laborum similique laudantium laboriosam veritatis eos assumenda inventore, repellendus pariatur ad recusandae, provident commodi totam quia vero est?
            </p>
        </div>
    );
}