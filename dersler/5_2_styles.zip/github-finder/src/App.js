function App() {
  return (
    <div className="bg-primary">
      github finder
    </div>
  );
}

export default App;
