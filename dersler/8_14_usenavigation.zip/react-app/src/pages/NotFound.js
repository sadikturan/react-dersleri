export const NotFound = () => {
    return (
        <div>404 page</div>
    );
}