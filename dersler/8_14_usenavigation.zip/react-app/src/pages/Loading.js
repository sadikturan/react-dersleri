export default function Loading() {
    return (
        <div className="fa-3x">
            <i className="fas fa-spinner fa-spin"></i>
        </div>
    );
}