
export const About = () =>  {
    return (
      <div className="about">
        <h2>Hakkımızda</h2>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur odio reprehenderit dicta, beatae assumenda doloremque, animi nobis vero vel natus perspiciatis corporis. Rem, voluptate perspiciatis. Dolore ab culpa modi quos.
        </p>
      </div>
    );
  }