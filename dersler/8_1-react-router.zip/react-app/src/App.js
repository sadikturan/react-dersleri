import './App.css';

function App() {
  return (
    <div className="App">
      Starter React Project
    </div>
  );
}

export default App;
