console.log("deneme");
console.log("deneme");