import NodeList from "./components/NoteList";

function App(props) {
  return (
    <>
      <NodeList />
    </>
  );
}

export default App;