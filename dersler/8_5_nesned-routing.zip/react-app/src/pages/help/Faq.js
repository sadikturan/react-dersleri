export const Faq = () => {
    return (
        <div className="faq">
            <h3>Sık Sorulan Sorular</h3>
            <div className="question">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores at facere quaerat laborum similique laudantium laboriosam veritatis eos assumenda inventore, repellendus pariatur ad recusandae, provident commodi totam quia vero est?
            </div>
            <div className="question">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores at facere quaerat laborum similique laudantium laboriosam veritatis eos assumenda inventore, repellendus pariatur ad recusandae, provident commodi totam quia vero est?
            </div>
            <div className="question">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores at facere quaerat laborum similique laudantium laboriosam veritatis eos assumenda inventore, repellendus pariatur ad recusandae, provident commodi totam quia vero est?
            </div>
        </div>
    );
}