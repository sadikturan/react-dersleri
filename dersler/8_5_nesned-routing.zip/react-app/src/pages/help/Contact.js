export const Contact = () => {
    return (
        <div className="contact">
            <h3>İletişim</h3>
            <form>
                <input type="text" />
                <button>Submit</button>
            </form>
        </div>
    );
}