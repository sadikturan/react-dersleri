import React from 'react';
import ReactDOM from 'react-dom';

const template = <p>Hello React!</p>;
ReactDOM.render(template, document.getElementById('root'));