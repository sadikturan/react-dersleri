import React from 'react';
import ReactDOM from 'react-dom';
import './styles/main.scss';

ReactDOM.render(<p>Starter React</p>, document.getElementById('root'));