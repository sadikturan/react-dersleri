// var nameVar = 'Sadık';
// var nameVar = 'Çınar';

// console.log(nameVar);

// let nameLet = 'Sadık';
// let nameLet = 'Çınar';

// console.log(nameLet);

// const nameConst = 'Sadık';
// console.log(nameConst);

// let age = 25;

// function getAge() {
//     let age = 30;
//     console.log('function scope: ', age);
// }

// console.log(age);
// getAge();

if(true) {
    let city = 'İstanbul';
    console.log(city);
}
console.log(city);
