import React from 'react'

const About = () => (
    <div className="container">
        <h1>About Page</h1>
    </div>
);

export default About
