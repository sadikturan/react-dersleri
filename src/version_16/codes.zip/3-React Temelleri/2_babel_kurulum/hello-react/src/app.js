  var root = document.getElementById('root');

  var template = <h1 id="header">Hello World</h1>;
 
  ReactDOM.render(template, root);