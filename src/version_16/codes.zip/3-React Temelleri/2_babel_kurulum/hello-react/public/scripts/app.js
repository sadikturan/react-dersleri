"use strict";

var root = document.getElementById('root');
var template = /*#__PURE__*/React.createElement("h1", {
  id: "header"
}, "Hello World");
ReactDOM.render(template, root);
